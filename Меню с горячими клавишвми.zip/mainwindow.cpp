#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QMessageBox>
#include <QFileDialog>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    // Связываем действия с слотами
    connect(ui->openAction_2, &QAction::triggered, this, &MainWindow::on_openAction_triggered);
    connect(ui->saveAction, &QAction::triggered, this, &MainWindow::on_saveAction_triggered);
    connect(ui->exitAction, &QAction::triggered, this, &MainWindow::on_exitAction_triggered);
    connect(ui->aboutAction, &QAction::triggered, this, &MainWindow::on_aboutAction_triggered);
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_openAction_triggered()
{
    QString fileName = QFileDialog::getOpenFileName(this, tr("Открыть файл"), "", tr("Text Files (*.txt);;All Files (*)"));
    if (!fileName.isEmpty()) {
        // Логика открытия файла
    }
}

void MainWindow::on_saveAction_triggered()
{
    QString fileName = QFileDialog::getSaveFileName(this, tr("Сохранить файл"), "", tr("Text Files (*.txt);;All Files (*)"));
    if (!fileName.isEmpty()) {
        // Логика сохранения файла
    }
}

void MainWindow::on_exitAction_triggered()
{
    QApplication::quit();
}

void MainWindow::on_aboutAction_triggered()
{
    QMessageBox::about(this, tr("О программе"), tr("Программа для ..."));
}
